function [p,q]=evenp(m,n,a,b,c,d)
%EVENP   It constructs the non uniform type-2 triangulation P_4
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
p=0;q=0;px=0;qy=0;
p(1)=-sin((1/(4*(m+1)))*pi);
p(2)=-sin((1/(10*m))*pi); 
q(1)=-sin((1/(4*(n+1)))*pi);
q(2)=-sin((1/(10*n))*pi);
for i=0:m/2
        p(i+3)=0.5*(cos((m/2-i)/m*pi)); 
end
px=1-p(3:2+(m/2));
px=px(length(px):-1:1);
p=[p px];
for i=0:n/2
        q(i+3)=0.5*(cos((n/2-i)/n*pi)); 
end
qy=1-q(3:2+(n/2));
qy=qy(length(qy):-1:1);
q=[q qy];
p(m+4)=1+sin((1/(10*m))*pi);
p(m+5)=1+sin((1/(4*(m+1)))*pi);  
q(n+4)=1+sin((1/(10*n))*pi);
q(n+5)=1+sin((1/(4*(n+1)))*pi);
p(3)=0;q(3)=0;
p=(b-a)*p+a;
q=(d-c)*q+c;
sort(p);sort(q);
