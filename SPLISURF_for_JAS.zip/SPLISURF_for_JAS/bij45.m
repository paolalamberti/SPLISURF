%BIJ45    This is a demo.
%         It plots the B-spline B_{IJ} in [0,1]�[0,1], for M=4, N=5
%         and for all I=0,...,M+1, J=0,...,N+1.
%       
%         See also BIJALL.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
%
bijall(4,5)