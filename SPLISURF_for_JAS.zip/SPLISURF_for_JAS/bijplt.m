function bijplt(m,n,i,j)
%BIJPLT     It plots the B-spline B_{IJ} in [0,1]�[0,1] 
%           for fixed values of M,N,I,J, where:
%           I=0,...,M+1, J=0,...,N+1;
%           M is the subdivisions number of [0,1] on the x-axis;
%           N is the subdivisions number of [0,1] on the y-axis.
%           If no input arguments are provided, bijplt plots 
%           the ZP-element.
% 
%           See also BIJ, OIJ.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
%
l1=30;
if nargin==4
	u=linspace(0,1,l1);
	v=linspace(0,1,l1);
   z=bij(u,v,m,n,i,j)';
   mesh(u,v,z);
	axis([0 1 0 1 0 1]);
	str1=sprintf('m = %g',m);
	text(1.5,0.9,0.9,str1);
	str2=sprintf(' n = %g',n);
	text(1.5,0.9,0.8,str2);
	str3=sprintf('  i = %g',i);
	text(1.5,0.9,0.7,str3);
	str4=sprintf('  j = %g',j);
	text(1.5,0.9,0.6,str4);
	str5=sprintf('B_{%g%g}',i,j);
   title(str5);
else
   u=linspace(-3/2,3/2,l1);
	v=linspace(-3/2,3/2,l1);
   z=bij(u,v)';
   mesh(u,v,z);
   axis([-3/2 3/2 -3/2 3/2 0 1])
   title('ZP-element')
end
xlabel('x')
ylabel('y')
zlabel('z')