function oijall(m,n)
%OIJALL     It plots the intersection of the octagon Q_{IJ}, support of 
%           the B-spline B_{IJ}, with [0,1]�[0,1] for fixed values of M
%           and N and for all I=0,...,M+1, J=0,...,N+1; M,N<=6.
%
%           See also OIJ. 
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
%
for i=0:m+1
  for j=0:n+1
    oij(m,n,i,j); 
    pause(1)
    hold off
  end
end 