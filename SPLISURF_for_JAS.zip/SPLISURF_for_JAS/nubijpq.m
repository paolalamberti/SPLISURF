%NUBIJPQ    This is a demo.
%           It plots all 'non-uniform' B-splines B^*_{IJ} in [0,1]�[0,1]
%           for the grid partition defined by the real vectors:
%           p=[-0.2 -0.1 0 0.5 0.75 1 1.1 1.2],
%           q=[-0.2 -0.1 0 0.6 0.8 1 1.1 1.2].
%               
%           See also NUBIJALL.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
p=[-0.2 -0.1 0 0.5 0.75 1 1.1 1.2];
q=[-0.2 -0.1 0 0.6 0.8 1 1.1 1.2];
nubijall(p,q)