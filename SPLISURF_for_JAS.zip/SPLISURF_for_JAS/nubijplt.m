function nubijplt(p,q,i,j,flag)
%NUBIJPLT   If FLAG is not present, it plots the 'non-uniform' B-spline B^*_{IJ}
%           in [A,B]�[C,D] for the given values of P,Q,I,J, otherwise it plots
%           the B-spline B^*_{IJ} on its support Q^*_{IJ} for any value of FLAG.
%           The real vectors P and Q define the following grid:
%           P: X_{-2} < X_{-1} < A = X_0 < X_1 < ... < X_M = B < X_{M+1} < X_{M+2},
%           Q: Y_{-2} < Y_{-1} < C = Y_0 < Y_1 < ... < Y_N = D < Y_{N+1} < Y_{N+2}.
%       
%           See also NUBIJ, NUOIJ.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
l1=30;
if nargin==4
   m=length(p)-5;
   n=length(q)-5;
   u=linspace(p(3),p(length(p)-2),l1);
   v=linspace(q(3),q(length(q)-2),l1);
   z=nubij(u,v,p,q,i,j)';
   mesh(u,v,z)
   axis([p(3) p(length(p)-2) q(3) q(length(q)-2) 0 1])
   title(sprintf('B^*_{%g%g},   m = %g,   n = %g',i,j,m,n));
else
   pk(1:4)=p([1:4]+i+1);
   qk(1:4)=q([1:4]+j+1);
   u=linspace(pk(1),pk(4),l1);
   v=linspace(qk(1),qk(4),l1);
   z=nubij(u,v,p,q,i,j)';
   mesh(u,v,z)
   axis([pk(1) pk(4) qk(1) qk(4) 0 1])
   title(sprintf('B^*_{%g%g}',i,j));
end
xlabel('x')
ylabel('y')
zlabel('z')