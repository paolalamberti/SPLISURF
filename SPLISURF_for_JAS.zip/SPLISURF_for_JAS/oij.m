function oij(m,n,i,j)
%OIJ     It plots the intersection of the octagon Q_{IJ}, support of the 
%        B-spline B_{IJ}, with [0,1]�[0,1], for fixed values of M,N,I,J,
%        where:
%            M is the subdivisions number of [0,1] on the x-axis;
%            N is the subdivisions number of [0,1] on the y-axis;
%            0<=I<=M+1, 0<=J<=N+1.
%        If there are no input parameters, the octagon Q, support of the
%        ZP-element, is plotted.
%
%        See also BIJ, BIJPLT.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
%
if nargin==0
   m=1; n=1; i=.5; j=.5;
end
p=(i-2)/m;
q=(i-1)/m;
r=i/m;
s=(i+1)/m;
t=(j-2)/n;
u=(j-1)/n;
v=j/n;
z=(j+1)/n;
x=[q q r r s p p s s q p r q p r s q];
y=[z t t z v v u u v t u z z v t u z];
xd=[(2*i-3)/(2*m) (2*i+1)/(2*m)];
yd=[(2*j+1)/(2*n) (2*j-3)/(2*n)];
plot(x,y)
hold on
plot(xd,yd,'--')
plot(xd,[yd(2) yd(1)],'--')
axis square
xlabel('x')
ylabel('y')
t=['text((32*i-17 )/(32*m ),( 2*j-1)/( 2*n),''1'')'; ...
   'text(( 8*i+1 )/( 8*m ),( 2*j-1)/( 2*n ),''2'')'; ...
   'text((12*i-7 )/(12*m ),(16*j+3)/(16*n ),''3'')'; ...
   'text(( 4*i-5 )/( 4*m ),( 2*j-1)/( 2*n ),''4'')'; ...
   'text((12*i-7)/(12*m ),(16*j-19)/(16*n ),''5'')'; ...
   'text((12*i+5)/(12*m ),(16*j-13)/(16*n ),''6'')'; ...
   'text(( 4*i+3)/( 4*m ),( 2*j-1 )/( 2*n ),''7'')'; ...
   'text((12*i+5)/(12*m ),(16*j-3 )/(16*n ),''8'')'; ...
   'text((12*i+5)/(12*m ),(16*j+3 )/(16*n ),''9'')'; ...
   'text(( 8*i+1)/( 8*m ),( 2*j+1 )/( 2*n),''10'')'; ...
   'text(( 4*i-1)/( 4*m ),( 2*j+1 )/( 2*n),''11'')'; ...
   'text((12*i-7)/(12*m ),(16*j+13)/(16*n),''12'')'; ...
   'text(( 8*i-7)/( 8*m ),( 2*j+1 )/( 2*n),''13'')'; ...
   'text(( 4*i-5)/( 4*m ),( 2*j+1 )/( 2*n),''14'')'; ...
   'text((12*i-19)/(12*m ),(16*j+3)/(16*n),''15'')'; ...
   'text((12*i-19)/(12*m ),(16*j-3)/(16*n),''16'')'; ...
   'text(( 8*i-15)/( 8*m ),( 2*j-1)/( 2*n),''17'')'; ...
   'text((12*i-19)/(12*m),(16*j-13)/(16*n),''18'')'; ...
   'text((12*i-19)/(12*m),(16*j-19)/(16*n),''19'')'; ...
   'text(( 4*i-5 )/( 4*m),( 2*j-3 )/( 2*n),''20'')'; ...
   'text(( 8*i-7 )/( 8*m),( 2*j-3 )/( 2*n),''21'')'; ...
   'text((12*i-7 )/(12*m),(16*j-29)/(16*n),''22'')'; ...
   'text(( 4*i-1 )/( 4*m),( 2*j-3 )/( 2*n),''23'')'; ...
   'text(( 8*i+1 )/( 8*m),( 2*j-3 )/( 2*n),''24'')'; ...
   'text((12*i+5 )/(12*m),(16*j-19)/(16*n),''25'')'];
if nargin==0
   for k=1:25
      eval(t(k,:));
   end
   title('Support Q');
else
   if (i==0)&(j==0)
      eval(t(9,:)); eval(t(10,:));
   elseif (i==0)&(j==1)
      eval(t(2,:)); eval(t(6,:)); eval(t(7,:)); eval(t(8,:)); eval(t(9,:));
      eval(t(10,:)); 
   elseif (i==0)&(j>=2)&(j<=(n-1))
      eval(t(2,:)); eval(t(6,:)); eval(t(7,:)); eval(t(8,:)); eval(t(9,:)); 
      eval(t(10,:)); eval(t(24,:)); eval(t(25,:));
   elseif (i==0)&(j==n)
      eval(t(2,:)); eval(t(6,:)); eval(t(7,:)); eval(t(8,:)); eval(t(24,:)); 
      eval(t(25,:));
   elseif (i==0)&(j==(n+1))
      eval(t(24,:)); eval(t(25,:));
   elseif (i==1)&(j==0)
      eval(t(3,:)); eval(t(9,:)); eval(t(10,:)); eval(t(11,:)); eval(t(12,:));
      eval(t(13,:));
   elseif (i==1)&(j==1)
      eval(t(1,:)); eval(t(2,:)); eval(t(3,:)); eval(t(6,:)); eval(t(7,:)); 
      eval(t(8,:)); eval(t(9,:)); eval(t(10,:)); eval(t(11,:)); eval(t(12,:));
      eval(t(13,:));
   elseif (i==1)&(j>=2)&(j<=(n-1))
      eval(t(1,:)); eval(t(2,:)); eval(t(3,:)); eval(t(5,:)); eval(t(6,:));
      eval(t(7,:)); eval(t(8,:)); eval(t(9,:)); eval(t(10,:)); eval(t(11,:));
      eval(t(12,:)); eval(t(13,:)); eval(t(21,:)); eval(t(22,:)); eval(t(23,:));
      eval(t(24,:)); eval(t(25,:));
   elseif (i==1)&(j==n)
      eval(t(1,:)); eval(t(2,:)); eval(t(5,:)); eval(t(6,:)); eval(t(7,:));
      eval(t(8,:)); eval(t(21,:)); eval(t(22,:)); eval(t(23,:)); eval(t(24,:));
      eval(t(25,:));
   elseif (i==1)&(j==(n+1))
      eval(t(5,:)); eval(t(21,:)); eval(t(22,:)); eval(t(23,:)); eval(t(24,:));
      eval(t(25,:));
   elseif (i>=2)&(i<=(m-1))&(j==0)
      eval(t(3,:)); eval(t(9,:)); eval(t(10,:)); eval(t(11,:)); eval(t(12,:)); 
      eval(t(13,:)); eval(t(14,:)); eval(t(15,:));
   elseif (i>=2)&(i<=(m-1))&(j==1)
      eval(t(1,:)); eval(t(2,:)); eval(t(3,:)); eval(t(4,:)); eval(t(6,:)); 
      eval(t(7,:)); eval(t(8,:)); eval(t(9,:)); eval(t(10,:)); eval(t(11,:)); 
      eval(t(12,:)); eval(t(13,:)); eval(t(14,:)); eval(t(15,:)); eval(t(16,:)); 
      eval(t(17,:)); eval(t(18,:));   
   elseif (i>=2)&(i<=(m-1))&(j>=2)&(j<=(n-1))
      eval(t(1,:)); eval(t(2,:)); eval(t(3,:)); eval(t(4,:)); eval(t(5,:)); 
      eval(t(6,:)); eval(t(7,:)); eval(t(8,:)); eval(t(9,:)); eval(t(10,:)); 
      eval(t(11,:)); eval(t(12,:)); eval(t(13,:)); eval(t(14,:)); eval(t(15,:));
      eval(t(16,:)); eval(t(17,:)); eval(t(18,:)); eval(t(19,:)); eval(t(20,:)); 
      eval(t(21,:)); eval(t(22,:)); eval(t(23,:)); eval(t(24,:)); eval(t(25,:));
   elseif (i>=2)&(i<=(m-1))&(j==n)
      eval(t(1,:)); eval(t(2,:)); eval(t(4,:)); eval(t(5,:)); eval(t(6,:));
      eval(t(7,:)); eval(t(8,:)); eval(t(16,:)); eval(t(17,:)); eval(t(18,:)); 
      eval(t(19,:)); eval(t(20,:)); eval(t(21,:)); eval(t(22,:)); eval(t(23,:));
      eval(t(24,:)); eval(t(25,:));
   elseif (i>=2)&(i<=(m-1))&(j==(n+1))
      eval(t(5,:)); eval(t(19,:)); eval(t(20,:)); eval(t(21,:)); eval(t(22,:)); 
      eval(t(23,:)); eval(t(24,:)); eval(t(25,:));
   elseif (i==m)&(j==0)
      eval(t(3,:)); eval(t(11,:)); eval(t(12,:)); eval(t(13,:)); eval(t(14,:));
      eval(t(15,:));
   elseif (i==m)&(j==1)
      eval(t(1,:)); eval(t(3,:)); eval(t(4,:)); eval(t(11,:)); eval(t(12,:));
      eval(t(13,:)); eval(t(14,:)); eval(t(15,:)); eval(t(16,:)); eval(t(17,:));
      eval(t(18,:));
   elseif (i==m)&(j>=2)&(j<=(n-1))
      eval(t(1,:)); eval(t(3,:)); eval(t(4,:)); eval(t(5,:)); eval(t(11,:));
      eval(t(12,:)); eval(t(13,:)); eval(t(14,:)); eval(t(15,:)); eval(t(16,:));
      eval(t(17,:)); eval(t(18,:)); eval(t(19,:)); eval(t(20,:)); eval(t(21,:));
      eval(t(22,:)); eval(t(23,:));
   elseif (i==m)&(j==n)
      eval(t(1,:)); eval(t(4,:)); eval(t(5,:)); eval(t(16,:)); eval(t(17,:));
      eval(t(18,:)); eval(t(19,:)); eval(t(20,:)); eval(t(21,:)); eval(t(22,:));
      eval(t(23,:));
   elseif (i==m)&(j==(n+1))
      eval(t(5,:)); eval(t(19,:)); eval(t(20,:)); eval(t(21,:)); eval(t(22,:));
      eval(t(23,:));
   elseif (i==(m+1))&(j==0)
      eval(t(14,:)); eval(t(15,:));       
   elseif (i==(m+1))&(j==1)
      eval(t(4,:)); eval(t(14,:)); eval(t(15,:)); eval(t(16,:)); eval(t(17,:));
      eval(t(18,:));
   elseif (i==(m+1))&(j>=2)&(j<=(n-1))
      eval(t(4,:)); eval(t(14,:)); eval(t(15,:)); eval(t(16,:)); eval(t(17,:));
      eval(t(18,:)); eval(t(19,:)); eval(t(20,:));
   elseif (i==(m+1))&(j==n)
      eval(t(4,:)); eval(t(16,:)); eval(t(17,:)); eval(t(18,:)); eval(t(19,:));
      eval(t(20,:)); 
   elseif (i==(m+1))&(j==(n+1))
      eval(t(19,:)); eval(t(20,:)); 
   end
   axis([0 1 0 1]);
   axis square;
   str1=sprintf('m = %g',m);
   text(1.05,1,str1);
   str2=sprintf(' n = %g',n);
   text(1.05,0.9,str2);
   str3=sprintf('  i = %g',i);
   text(1.05,0.8,str3);
   str4=sprintf('  j = %g',j);
   text(1.05,0.7,str4);
   str5=sprintf('Q_{%g%g}',i,j);
   title(str5);
end