function l=lw(m,n,a,b,c,d,sf)
%LW    It returns the matrix L of size (M+2)(N+2) of the linear functionals
%      defining the spline W_{MN}F for a given test function F over an open 
%      set containing the rectangle [A,B]x[C,D], where M is the subdivisions
%      number of [A,B] and N is the subdivisions number of [C,D].
%      SF is the string containing either the function F or the name of 
%      the m-file with .M extension in which the function F is defined.
%
%      Ex. sf='(1+2*exp((-3)*(sqrt(x.^2+y.^2)-6.7))).^(-1/2)';
%          l=lw(3,3,0,10,0,10,sf)
%
%          return
%
%          l=
%             -0.0092   -0.0092   -0.2119    1.1241    1.0000
%             -0.0092   -0.0092   -0.2119    1.1241    1.0000
%             -0.2119   -0.2119    0.8400    1.0224    1.0000
%              1.1241    1.1241    1.0224    1.0001    1.0000
%              1.0000    1.0000    1.0000    1.0000    1.0000
%
%      See also AMN, LV.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
%
[h k]=size(sf);
if k~=1
   sf1=sf(k-1:k);
else
   sf1=sf;
end
[XI,YJ]=meshgrid(-1/(2*m):1/m:(2*m+1)/(2*m),-1/(2*n):1/n:(2*n+1)/(2*n));
[IM,JN]=meshgrid(-1/m:1/m:(m+1)/m,-1/n:1/n:(n+1)/n);
if strcmp(sf1,'.m')
   sf2=sf(1:k-2);
   m1=feval(sf2,(b-a)*XI'+a,(d-c)*YJ'+c);
   m2=feval(sf2,(b-a)*IM'+a,(d-c)*JN'+c);
else
   x=(b-a)*XI'+a;
   y=(d-c)*YJ'+c;
   m1=eval(sf);
   x=(b-a)*IM'+a;
   y=(d-c)*JN'+c;
   m2=eval(sf);
end
[H K]=size(m2);
l=2*m1-(1/4)*(m2(2:H,2:K)+m2(1:H-1,2:K)+m2(1:H-1,1:K-1)+m2(2:H,1:K-1));