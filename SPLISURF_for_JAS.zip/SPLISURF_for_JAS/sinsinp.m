function [p,q]=sinsinp(m,n,a,b,c,d)
%SINSINP  It constructs the non uniform type-2 triangulation P_1
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
p=0;
q=0;
p(1)=-sin((1/(4*(m+1)))*pi);
p(2)=-sin((1/(10*m))*pi); 
q(1)=-sin((1/(4*(n+1)))*pi);
q(2)=-sin((1/(10*n))*pi);
for i=0:m 
      p(i+3)=(sin(((m-i)/m)*pi))/5+i/m;
end 
for i=0:n
      q(i+3)=(sin(((n-i)/n)*pi))/5+i/n; 
end
p(m+4)=1+sin((1/(10*m))*pi);
p(m+5)=1+sin((1/(4*(m+1)))*pi);  
q(n+4)=1+sin((1/(10*n))*pi);
q(n+5)=1+sin((1/(4*(n+1)))*pi);
p(3)=0;q(3)=0;
p=(b-a)*p+a;
q=(d-c)*q+c;
sort(p); sort(q);