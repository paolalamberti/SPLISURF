function l=nulw(p,q,a,b,c,d,sf)
%NULW   It returns the matrix L of size (M+2)(N+2) of the linear functionals
%       defining the spline W^*_{MN}F for a given test function F over an open
%       set containing the rectangle [A,B]x[C,D].
%       The real vectors P and Q define the following grid:
%       P: X_{-2} < X_{-1} < A = X_0 < X_1 < ... < X_M = B < X_{M+1} < X_{M+2},
%       Q: Y_{-2} < Y_{-1} < C = Y_0 < Y_1 < ... < Y_N = D < Y_{N+1} < Y_{N+2}.
%       SF is the string containing either the function F or the name of 
%       the m-file with .M extension in which the function F is defined.
% 
%       See also NUAMN, NULV. 
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
[h k]=size(sf);
if k~=1
   sf1=sf(k-1:k);
else
   sf1=sf;
end
pm=(p(2:length(p)-2)+p(3:length(p)-1))./2;
qm=(q(2:length(q)-2)+q(3:length(q)-1))./2;
[XI,YJ]=meshgrid(pm,qm);
[IM,JN]=meshgrid(p(2:length(p)-1),q(2:length(q)-1));
if strcmp(sf1,'.m')
   sf2=sf(1:k-2);
   m1=feval(sf2,XI',YJ');
   m2=feval(sf2,IM',JN');
else
   x=XI'; y=YJ';
   m1=eval(sf);
   x=IM'; y=JN';
   m2=eval(sf);
end
[H K]=size(m2);
l=2*m1-(1/4)*(m2(2:H,2:K)+m2(1:H-1,2:K)+m2(1:H-1,1:K-1)+m2(2:H,1:K-1));