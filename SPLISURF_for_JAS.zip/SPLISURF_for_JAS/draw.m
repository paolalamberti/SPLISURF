function draw(p,q)
%DRAW    Given two real vectors P and Q defining the rectangular grid:
%        P: X_{-2} < X_{-1} < A = X_0 < X_1 < ... < X_M = B < X_{M+1} < X_{M+2},
%        Q: Y_{-2} < Y_{-1} < C = Y_0 < Y_1 < ... < Y_N = D < Y_{N+1} < Y_{N+2},
%        DRAW displays the corresponding non uniform type-2 triangulation.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
m=length(p)-5;
n=length(q)-5;
pm=0;
qm=0;
for i=1:length(p)-1
       pm(i)=(p(i)+p(i+1))/2;
end
for i=1:length(q)-1
       qm(i)=(q(i)+q(i+1))/2;
end
[P,Q]=meshgrid(p,q);
line(P,Q,'Marker','.','MarkerSize',12,'LineStyle','none');
hold on
plot([p(3) p(m+3) p(m+3) p(3) p(3)],[q(3) q(3) q(n+3) q(n+3) q(3)],'k')
[PM,QM]=meshgrid(pm,qm);
line(PM,QM,'Marker','.','MarkerSize',12,'LineStyle','none');
if (m<=8)&(n<=8)
      plot([p(1) p(m+5) p(m+5) p(1) p(1)],[q(1) q(1) q(n+5) q(n+5) q(1)],'k:');
      for i=2:m+4
           plot([p(i) p(i)],[q(1) q(n+5)],'k:');
      end
      for i=2:n+4
           plot([p(1) p(m+5)],[q(i) q(i)],'k:');
      end
end 
axis equal
axis([p(1) p(m+5) q(1) q(n+5)])
str=sprintf('m=%g , n=%g',m,n);
title(str);