%AMNF     This is a demo.
%         APPROXIMATION OF SOME TEST FUNCTIONS 
%         BY BIVARIATE QUADRATIC C^1 QUASI-INTERPOLATING SPLINES
%         ON UNIFORM TYPE-2 TRIANGULATIONS
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
%
disp(' ');
disp(' ');
disp('APPROXIMATION OF SOME TEST FUNCTIONS');
disp('BY BIVARIATE QUADRATIC C^1 QUASI-INTERPOLATING SPLINES');
disp('ON UNIFORM TYPE-2 TRIANGULATIONS');
disp(' ');
disp(' ');
disp(' ');
disp('We want to approximate data taken from the test function');
disp('obtained by the following commands on the domain [0,1]x[0,1]:');
disp(' ');
echo on
u=linspace(0,1,30);
v=linspace(0,1,30);
[U,V]=meshgrid(u,v);
Z=1/9*(tanh(9*V-9*U)+1);
mesh(U,V,Z)
echo off
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('First we construct the functionals matrix defining');
disp('the spline operator V_{mn} for m=n=8 in [0,1]x[0,1]:');
disp(' ');
echo on
l=lv(8,8,0,1,0,1,'1/9*(tanh(9*y-9*x)+1)');
echo off
disp(' ');
disp('Then we evaluate the spline at the points uxv of [0,1]x[0,1]:');
disp(' ');
echo on
z=amn(u,v,0,1,0,1,l)';
echo off
disp(' ');
disp('... and we plot the spline approximation by using');
disp(' ');
echo on
figure
mesh(u,v,z)
xlabel('x'); ylabel('y'); zlabel('z');
echo off
disp(' ');
disp('Now we compute the maximum absolute error at the points uxv:');
echo on
max_err=max(max(z-Z))
echo off
disp(' ');
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp(' ');
clf
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Now let''s see another example.');
disp(' ');
disp('On the same domain we consider the test function');
echo on
Z=sin(pi*U.*(1-V));
mesh(U,V,Z)
echo off
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('The functionals matrix defining the spline');
disp('operator W_{mn} for m=7, n=10 is the following:');
disp(' ');
echo on
l=lw(7,10,0,1,0,1,'sin(pi*x.*(1-y))');
echo off
disp(' ');
disp('Thus we evaluate the spline at the points uxv of [0,1]x[0,1],');
disp(' ');
echo on
z=amn(u,v,0,1,0,1,l)';
echo off
disp(' ');
disp('... we plot the spline approximation');
disp(' ');
echo on
figure
mesh(u,v,z)
axis([u(1) u(length(u)) v(1) v(length(v)) min(min(z)) max(max(z))])
xlabel('x'); ylabel('y'); zlabel('z');
echo off
disp(' ');
disp('... and we compute the maximum absolute error at the points uxv:');
echo on
max_err=max(max(z-Z))
echo off
disp(' ');
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp(' ');
clf
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Let''s consider the following test function');
disp(' ');
echo on
Z=sqrt(abs(U-V));
mesh(U,V,Z)
echo off
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('The spline defining the operator V_{35,50} is obtained by');
disp(' ');
echo on
l=lv(35,50,0,1,0,1,'sqrt(abs(x-y))');
z=amn(u,v,0,1,0,1,l)';
figure
mesh(u,v,z)
axis([u(1) u(length(u)) v(1) v(length(v)) min(min(z)) max(max(z))])
xlabel('x'); ylabel('y'); zlabel('z');
echo off
disp(' ');
disp('... and the maximum absolute error by');
max_err=max(max(z-Z))
echo off
disp(' ');
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp(' ');
clf
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Finally for the following test function defined on [-1,1]x[-1,1]');
disp(' ');
echo on
u=linspace(-1,1,30); v=linspace(-1,1,30);
[U,V]=meshgrid(u,v);
Z=abs(U.^2+V.^2-.25);
mesh(U,V,Z)
echo off
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('we have');
disp(' ');
echo on
l=lv(16,28,-1,1,-1,1,'abs(x.^2+y.^2-.25)');
z=amn(u,v,-1,1,-1,1,l).';
figure
mesh(u,v,z)
axis([u(1) u(length(u)) v(1) v(length(v)) min(min(z)) max(max(z))])
xlabel('x'); ylabel('y'); zlabel('z');
max_err=max(max(z-Z))
echo off