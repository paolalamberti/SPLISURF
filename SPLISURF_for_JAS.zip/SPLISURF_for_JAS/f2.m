function f=f2(x,y)
%F2   Test function f2:
%     f2(x,y)=abs(x)*y   if   x*y>0
%     f2(x,y)=0          elsewhere
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
% [3] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
f=zeros(size(x));
R=(x.*y>0);
f=f+R.*abs(x).*y;