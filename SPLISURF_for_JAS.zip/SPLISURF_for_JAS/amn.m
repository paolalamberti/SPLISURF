function z=amn(u,v,a,b,c,d,l)
%AMN   Evaluation of a q-i spline AF with a uniform type-2 triangulation
%      of [A,B]�[C,D] at UxV, where U and V are two real vectors.
%      L is the matrix of size (M+2)(N+2) of the linear functionals
%      defining the q-i spline AF, where M is the subdivisions number of
%      [A,B] and N is the subdivisions number of [C,D]. 
%      
%      Ex. sf='(1+2*exp((-3)*(10*sqrt(x.^2+y.^2)-6.7))).^(-1/2)';
%          l=lv(3,3,0,1,0,1,sf);
%          z=amn(.5,.5,0,1,0,1,l)
%
%          return
%
%          z =
%              0.65903463183787
%
%          i.e. V_{33}f(0.5,0.5).
%
%      See also BIJ, LV, LW. 
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
%
[h k]=size(l);
m=h-2; n=k-2;
uaba=(u-a)./(b-a); vcdc=(v-c)./(d-c);
iu=ceil(m*uaba); jv=ceil(n*vcdc);
Ru=(iu==0); iu=iu+Ru; Rv=(jv==0); jv=jv+Rv;
z=bij(uaba,vcdc,m,n,iu-1,jv-1).*l(iu,jv) ...
 +bij(uaba,vcdc,m,n,iu-1,jv).*l(iu,jv+1) ...
 +bij(uaba,vcdc,m,n,iu-1,jv+1).*l(iu,jv+2) ...
 +bij(uaba,vcdc,m,n,iu,jv-1).*l(iu+1,jv) ...
 +bij(uaba,vcdc,m,n,iu,jv).*l(iu+1,jv+1) ...
 +bij(uaba,vcdc,m,n,iu,jv+1).*l(iu+1,jv+2) ...
 +bij(uaba,vcdc,m,n,iu+1,jv-1).*l(iu+2,jv) ...
 +bij(uaba,vcdc,m,n,iu+1,jv).*l(iu+2,jv+1) ...
 +bij(uaba,vcdc,m,n,iu+1,jv+1).*l(iu+2,jv+2);