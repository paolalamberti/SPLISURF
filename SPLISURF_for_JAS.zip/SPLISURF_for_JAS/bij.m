function b=bij(u,v,m,n,i,j)
%BIJ     Evaluation of the B-spline B_{IJ} for a uniform type-2
%        triangulation at UxV in R^2, for fixed values of
%        M,N,I,J, where:
%            U and V are two real vectors;
%            M is the subdivisions number of [0,1] on the x-axis;
%            N is the subdivisions number of [0,1] on the y-axis.
%        b is the matrix containing the B-spline values at UxV.
%        B_{IJ}(X,Y) is so defined: 
%        B_{IJ}(X,Y)=B(M*X-I+1/2,N*Y-J+1/2), I=0,...,M+1, J=0,...,N+1,
%        where B is the ZP-element.
%        If b=BIJ(U,V) is provided, then the ZP-element is obtained.
%
%        Ex. b=bij(5/6,5/6,3,3,3,3)
%
%            returns
%
%            b =
%                 0.5
%
%            i.e. B_{33}(5/6,5/6) and
%				 
%            b=bij(0,0)
%
%            returns
%
%            b =
%                 0.5
%
%        See also AMN, BIJPLT, OIJ.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
%
if nargin==6
	u=m*u-i+1/2;
   v=n*v-j+1/2;
end
[U,V]=meshgrid(u,v);
U=U'; V=V';
b=zeros(size(U));

Ru=(U>-3/2)&(U<=-1/2);
Rv=(V>=-U-1)&(V<=U+1)&~(U==-1/2 & V==-1/2)&~(U==-1/2 & V==1/2);
b=b+Ru.*Rv.*(5/8+(1/2)*U-(1/2)*V.^2);										%4
Rv=(V>=1/2)&(V<U+2);
b=b+Ru.*Rv.*(1-V+(1/4)*V.^2-(-1+(1/2)*V).*U+(1/4)*U.^2);				%14
Rv=(V>-U-1)&(V>U+1)&(V<1/2);
b=b+Ru.*Rv.*(7/8+U+(1/4)*U.^2-(1/2+(1/2)*U).*V-(1/4)*V.^2);			%16
Rv=(V>=U+1)&(V<=-U-1)&~(U==-1 & V==0);
b=b+Ru.*Rv.*(9/8+(3/2)*U+(1/2)*U.^2);										%17
Rv=(V>-1/2)&(V<U+1)&(V<-U-1);
b=b+Ru.*Rv.*(7/8+U+(1/4)*U.^2+(1/2+(1/2)*U).*V-(1/4)*V.^2);			%18
Rv=(V>-U-2)&(V<=-1/2);
b=b+Ru.*Rv.*(1+U+(1/4)*U.^2-(-1-(1/2)*U).*V+(1/4)*V.^2);				%19

Ru=(U>-1/2)&(U<1/2);
Rv=(V>-1/2)&(V<1/2);
b=b+Ru.*Rv.*(1/2-(1/2)*U.^2-(1/2)*V.^2);									%1
Rv=(V<-U+1)&(V<U+1)&(V>=1/2);
b=b+Ru.*Rv.*(5/8-(1/2)*V-(1/2)*U.^2);										%3
Rv=(V>-U-1)&(V>U-1)&(V<=-1/2);
b=b+Ru.*Rv.*(5/8+(1/2)*V-(1/2)*U.^2);										%5
Rv=(V>=-U+1)&(V<=U+1);
b=b+Ru.*Rv.*(7/8-V+(1/4)*V.^2-(1/2-(1/2)*V).*U-(1/4)*U.^2);			%11
Rv=(V<=3/2)&(V>U+1)&(V>-U+1);
b=b+Ru.*Rv.*(9/8-(3/2)*V+(1/2)*V.^2);										%12
Rv=(V<=-U+1)&(V>=U+1)&~(U==0 & V==1);
b=b+Ru.*Rv.*(7/8-V+(1/4)*V.^2+(1/2-(1/2)*V).*U-(1/4)*U.^2);			%13
Rv=(V>=U-1)&(V<=-U-1)&~(U==0 & V==-1);
b=b+Ru.*Rv.*(7/8+V+(1/4)*V.^2+(1/2+(1/2)*V).*U-(1/4)*U.^2);			%21
Rv=(V>=-3/2)&(V<U-1)&(V<-U-1);
b=b+Ru.*Rv.*(9/8+(3/2)*V+(1/2)*V.^2);										%22
Rv=(V>=-U-1)&(V<=U-1);
b=b+Ru.*Rv.*(7/8+V+(1/4)*V.^2-(1/2+(1/2)*V).*U-(1/4)*U.^2);			%23

Ru=(U>=1/2)&(U<3/2);
Rv=(V>=U-1)&(V<=-U+1)&~(U==1/2 & V==-1/2)&~(U==1/2 & V==1/2);
b=b+Ru.*Rv.*(5/8-(1/2)*U-(1/2)*V.^2);										%2
Rv=(V>-1/2)&(V<U-1)&(V<-U+1);
b=b+Ru.*Rv.*(7/8-U+(1/4)*U.^2+(1/2-(1/2)*U).*V-(1/4)*V.^2);			%6
Rv=(V>=-U+1)&(V<=U-1)&~(U==1 & V==0);
b=b+Ru.*Rv.*(9/8-(3/2)*U+(1/2)*U.^2);										%7
Rv=(V>-U+1)&(V>U-1)&(V<1/2);
b=b+Ru.*Rv.*(7/8-U+(1/4)*U.^2-(1/2-(1/2)*U).*V-(1/4)*V.^2);			%8
Rv=(V>=1/2)&(V<-U+2);
b=b+Ru.*Rv.*(1-U+(1/4)*U.^2+(-1+(1/2)*U).*V+(1/4)*V.^2);				%9
Rv=(V>U-2)&(V<=-1/2);
b=b+Ru.*Rv.*(1+V+(1/4)*V.^2+(-1-(1/2)*V).*U+(1/4)*U.^2);				%24