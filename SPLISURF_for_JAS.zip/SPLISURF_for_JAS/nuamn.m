function z=nuamn(u,v,p,q,a,b,c,d,l)
%NUAMN   Evaluation of a q-i spline A^*F with a non uniform type-2 triangulation
%        of [A,B]�[C,D] at UxV, where U and V are two real vectors.
%        The real vectors P and Q define the following grid:
%        P: X_{-2} < X_{-1} < A = X_0 < X_1 < ... < X_M = B < X_{M+1} < X_{M+2},
%        Q: Y_{-2} < Y_{-1} < C = Y_0 < Y_1 < ... < Y_N = D < Y_{N+1} < Y_{N+2}.
%        L is the matrix of size (M+2)(N+2) of the linear functionals defining
%        the q-i spline A^*F.
%      
%        Ex. p=[-0.2 -0.1 0 0.5 0.75 1 1.1 1.2];
%            q=[-0.2 -0.1 0 0.6 0.8 1 1.1 1.2];
%            sf='(1+2*exp((-3)*(10*sqrt(x.^2+y.^2)-6.7))).^(-1/2)';
%            l=nulv(p,q,0,1,0,1,sf);
%            z=nuamn(.5,.5,p,q,0,1,0,1,l)
%
%            return
%
%            z =
%                0.72625444692033
%
%            i.e. V^*_{33}f(0.5,0.5).
% 
%      	See also NUBIJ, NULV, NULW.  
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
p1=p(3:length(p)-2);
flag=0*u; ind1=1+0*u; ind2=length(p1)+0*u;
while all(flag)<1+0*u
      iu=floor((ind1+ind2)./2);
      R1=(u>=p1(iu));
      R2=(u<=p1(iu+1));
      flag=flag+R1.*R2;
      ind1=(1-R2).*iu+R2.*ind1;
      ind2=(1-R1).*iu+R1.*ind2;
end
q1=q(3:length(q)-2);
flag=0*v; ind1=1+0*v; ind2=length(q1)+0*v;
while all(flag)<1+0*v
      jv=floor((ind1+ind2)./2);
      R1=(v>=q1(jv));
      R2=(v<=q1(jv+1));
      flag=flag+R1.*R2;
      ind1=(1-R2).*jv+R2.*ind1;
      ind2=(1-R1).*jv+R1.*ind2;
end
z=nubij(u,v,p,q,iu-2,jv-2).*l(iu,jv) ...
 +nubij(u,v,p,q,iu-2,jv-1).*l(iu,jv+1) ...
 +nubij(u,v,p,q,iu-2,jv).*l(iu,jv+2) ...
 +nubij(u,v,p,q,iu-1,jv-2).*l(iu+1,jv) ...
 +nubij(u,v,p,q,iu-1,jv-1).*l(iu+1,jv+1) ...
 +nubij(u,v,p,q,iu-1,jv).*l(iu+1,jv+2) ...
 +nubij(u,v,p,q,iu,jv-2).*l(iu+2,jv) ...
 +nubij(u,v,p,q,iu,jv-1).*l(iu+2,jv+1) ...
 +nubij(u,v,p,q,iu,jv).*l(iu+2,jv+2);