function nuoij(p,q,i,j,flag)
%NUOIJ   If FLAG is not present, it plots the intersection of the 'non-uniform' 
%        octagon Q^*_{IJ} with [A,B]�[C,D] for the given values of P,Q,I,J,
%        otherwise it plots all the support Q^*_{IJ} for any value of FLAG.
%        The real vectors P and Q define the following grid:
%        P: X_{-2} < X_{-1} < A = X_0 < X_1 < ... < X_M = B < X_{M+1} < X_{M+2},
%        Q: Y_{-2} < Y_{-1} < C = Y_0 < Y_1 < ... < Y_N = D < Y_{N+1} < Y_{N+2}.
%
%        See also NUBIJ, NUBIJPLT.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
pk(1:4)=p([1:4]+i+1);
qk(1:4)=q([1:4]+j+1);
pc(1:3)=pk(1:3)+(pk(2:4)-pk(1:3))/2;
qc(1:3)=qk(1:3)+(qk(2:4)-qk(1:3))/2;
x1=[pk(2) pk(2) pk(3) pk(3) pk(4) pk(4) pk(3) pk(2) pk(1) pk(2) pk(3) pk(4) ...
    pk(1) pk(1) pk(2) pk(3) pk(2) pk(1) pk(2) pk(4) pk(3) pk(2)];
y1=[qk(4) qk(1) qk(1) qk(4) qk(3) qk(2) qk(1) qk(2) qk(2) qk(1) qk(2) qk(3) ...
    qk(3) qk(2) qk(3) qk(4) qk(4) qk(3) qk(2) qk(2) qk(3) qk(4)];
x2=[pk(2) pk(3)]; y2=[qk(3) qk(2)];
x3=[pk(2) pc(1)]; y3=[qk(2) qc(1)];
x4=[pk(2) pc(1)]; y4=[qk(3) qc(3)];
x5=[pk(3) pc(3)]; y5=[qk(2) qc(1)];
x6=[pk(3) pc(3)]; y6=[qk(3) qc(3)];
plot(x1,y1)
hold on
plot(x2,y2)
plot(x2,[y2(2) y2(1)])
plot(x3,y3,'--')
plot(x4,y4,'--')
plot(x5,y5,'--')
plot(x6,y6,'--')
xlabel('x')
ylabel('y')
nut=['text(pk(2)+(3*(pk(3)-pk(2)))/4,qk(2)+(qk(3)-qk(2))/2, ''1.a'',''FontSize'',9)'; ...
   'text(pk(2)+(pk(3)-pk(2))/2,qk(2)+(7*(qk(3)-qk(2)))/8, ''1.b'',''FontSize'',9)'; ...
   'text(pk(2)+(pk(3)-pk(2))/8,qk(2)+(qk(3)-qk(2))/2,  ''1.c'', ''FontSize'',  9)'; ...
   'text(pk(2)+(pk(3)-pk(2))/2,qk(2)+(qk(3)-qk(2))/8,  ''1.d'', ''FontSize'',  9)'; ...
   'text(pk(3)+(pk(4)-pk(3))/8,qk(2)+(qk(3)-qk(2))/2,   ''2'',  ''FontSize'',  9)'; ...
   'text(pk(2)+(pk(3)-pk(2))/2,qk(3)+(qk(4)-qk(3))/8,   ''3'',  ''FontSize'',  9)'; ...
   'text(p(i+2)+(3*(pk(2)-pk(1)))/4,qk(2)+(qk(3)-qk(2))/2, ''4'',''FontSize'', 9)'; ...
   'text(pk(2)+(pk(3)-pk(2))/2,q(j+2)+(7*(qk(2)-qk(1)))/8, ''5'',''FontSize'', 9)'; ...
   'text(pk(3)+(pk(4)-pk(3))/2,qk(2)+(qk(3)-qk(2))/8,   ''6'',  ''FontSize'',  9)'; ...
   'text(pk(3)+(7*(pk(4)-pk(3)))/8,qk(2)+(qk(3)-qk(2))/2, ''7'', ''FontSize'', 9)'; ...
   'text(pk(3)+(pk(4)-pk(3))/2,qk(2)+(7*(qk(3)-qk(2)))/8, ''8'', ''FontSize'', 9)'; ...
   'text(pk(3)+((pk(4)-pk(3))/2),qk(3)+(qk(4)-qk(3))/4,  ''9'',  ''FontSize'', 9)'; ...
   'text(pk(3)+((pk(4)-pk(3))/8),qk(3)+(qk(4)-qk(3))/2,  ''10'', ''FontSize'', 9)'; ...
   'text(pk(2)+(3*(pk(3)-pk(2)))/4,qk(3)+(qk(4)-qk(3))/2, ''11'',''FontSize'', 9)'; ...
   'text(pk(2)+(pk(3)-pk(2))/2,qk(3)+(7*(qk(4)-qk(3)))/8, ''12'',''FontSize'', 9)'; ...
   'text(pk(2)+(pk(3)-pk(2))/8,qk(3)+(qk(4)-qk(3))/2,  ''13'',  ''FontSize'',  9)'; ...
   'text(p(i+2)+(3*(pk(2)-pk(1)))/4,qk(3)+(qk(4)-qk(3))/2,''14'',''FontSize'', 9)'; ...
   'text(p(i+2)+(pk(2)-pk(1))/2,qk(3)+(qk(4)-qk(3))/8,  ''15'',  ''FontSize'', 9)'; ...
   'text(p(i+2)+(pk(2)-pk(1))/2,qk(2)+(7*(qk(3)-qk(2)))/8, ''16'',''FontSize'',9)'; ...
   'text(p(i+2)+(pk(2)-pk(1))/8,qk(2)+(qk(3)-qk(2))/2, ''17'',  ''FontSize'',  9)'; ...
   'text(p(i+2)+(pk(2)-pk(1))/2,qk(2)+(qk(3)-qk(2))/8, ''18'',  ''FontSize'',  9)'; ...
   'text(p(i+2)+(pk(2)-pk(1))/2,q(j+2)+(7*(qk(2)-qk(1)))/8,''19'',''FontSize'',9)'; ...
   'text(p(i+2)+(3*(pk(2)-pk(1)))/4,q(j+2)+(qk(2)-qk(1))/2,''20'',''FontSize'',9)'; ...
   'text(pk(2)+(pk(3)-pk(2))/8,q(j+2)+(qk(2)-qk(1))/2,  ''21'',  ''FontSize'', 9)'; ...
   'text(pk(2)+(pk(3)-pk(2))/2,q(j+2)+(qk(2)-qk(1))/8,  ''22'',  ''FontSize'', 9)'; ...
   'text(pk(2)+(3*(pk(3)-pk(2)))/4,q(j+2)+(qk(2)-qk(1))/2,''23'',''FontSize'', 9)'; ...
   'text(pk(3)+(pk(4)-pk(3))/8,q(j+2)+(qk(2)-qk(1))/2, ''24'',  ''FontSize'',  9)'; ...
   'text(pk(3)+(pk(4)-pk(3))/2,q(j+2)+(7*(qk(2)-qk(1)))/8,''25'',''FontSize'', 9)'];
m=length(p)-5;
n=length(q)-5;
if nargin==5
	for k=1:28
    	 eval(nut(k,:));
   end
   str=sprintf('Q^*_{%g%g}',i,j);
   title(str);
else
   if (i==-1)&(j==-1)
      eval(nut(12,:)); eval(nut(13,:));
   elseif (i==-1)&(j==0)
      eval(nut(5,:)); eval(nut(9,:)); eval(nut(10,:)); eval(nut(11,:));
      eval(nut(12,:)); eval(nut(13,:));
   elseif (i==-1)&(j>=1)&(j<=(n-2))
      eval(nut(5,:)); eval(nut(9,:)); eval(nut(10,:)); eval(nut(11,:));
      eval(nut(12,:)); eval(nut(13,:)); eval(nut(27,:)); eval(nut(28,:));
   elseif (i==-1)&(j==(n-1))
      eval(nut(5,:)); eval(nut(9,:)); eval(nut(10,:)); eval(nut(11,:));
      eval(nut(27,:)); eval(nut(28,:));
   elseif (i==-1)&(j==n)
      eval(nut(27,:)); eval(nut(28,:));
   elseif (i==0)&(j==-1)
      eval(nut(6,:)); eval(nut(12,:)); eval(nut(13,:)); eval(nut(14,:));
      eval(nut(15,:)); eval(nut(16,:));
   elseif (i==0)&(j==0)
      eval(nut(1,:)); eval(nut(2,:)); eval(nut(3,:)); eval(nut(4,:));
      eval(nut(5,:)); eval(nut(6,:)); eval(nut(9,:)); eval(nut(10,:));
      eval(nut(11,:)); eval(nut(12,:)); eval(nut(13,:)); eval(nut(14,:));
      eval(nut(15,:)); eval(nut(16,:));
   elseif (i==0)&(j>=1)&(j<=(n-2))
      eval(nut(1,:)); eval(nut(2,:)); eval(nut(3,:)); eval(nut(4,:));
      eval(nut(5,:)); eval(nut(6,:)); eval(nut(8,:)); eval(nut(9,:));
      eval(nut(10,:)); eval(nut(11,:)); eval(nut(12,:)); eval(nut(13,:));
      eval(nut(14,:)); eval(nut(15,:)); eval(nut(16,:)); eval(nut(24,:));
      eval(nut(25,:)); eval(nut(26,:)); eval(nut(27,:)); eval(nut(28,:));
   elseif (i==0)&(j==(n-1))
      eval(nut(1,:)); eval(nut(2,:)); eval(nut(3,:)); eval(nut(4,:));
      eval(nut(5,:)); eval(nut(8,:)); eval(nut(9,:)); eval(nut(10,:));
      eval(nut(11,:)); eval(nut(24,:)); eval(nut(25,:)); eval(nut(26,:));
      eval(nut(27,:)); eval(nut(28,:));
   elseif (i==0)&(j==n)
      eval(nut(8,:)); eval(nut(24,:)); eval(nut(25,:)); eval(nut(26,:));
      eval(nut(27,:)); eval(nut(28,:));
   elseif (i>=1)&(i<=(m-2))&(j==-1)
      eval(nut(6,:)); eval(nut(12,:)); eval(nut(13,:)); eval(nut(14,:));
      eval(nut(15,:)); eval(nut(16,:)); eval(nut(17,:)); eval(nut(18,:));
   elseif (i>=1)&(i<=(m-2))&(j==0)
      eval(nut(1,:)); eval(nut(2,:)); eval(nut(3,:)); eval(nut(4,:));
      eval(nut(5,:)); eval(nut(6,:)); eval(nut(7,:)); eval(nut(9,:));
      eval(nut(10,:)); eval(nut(11,:)); eval(nut(12,:)); eval(nut(13,:));
      eval(nut(14,:)); eval(nut(15,:)); eval(nut(16,:)); eval(nut(17,:));
      eval(nut(18,:)); eval(nut(19,:)); eval(nut(20,:)); eval(nut(21,:));
   elseif (i>=1)&(i<=(m-2))&(j>=1)&(j<=(n-2))
      eval(nut(1,:)); eval(nut(2,:)); eval(nut(3,:)); eval(nut(4,:));
      eval(nut(5,:)); eval(nut(6,:)); eval(nut(7,:)); eval(nut(8,:));
      eval(nut(9,:)); eval(nut(10,:)); eval(nut(11,:)); eval(nut(12,:));
      eval(nut(13,:)); eval(nut(14,:)); eval(nut(15,:)); eval(nut(16,:));
      eval(nut(17,:)); eval(nut(18,:)); eval(nut(19,:)); eval(nut(20,:));
      eval(nut(21,:)); eval(nut(22,:)); eval(nut(23,:)); eval(nut(24,:));
      eval(nut(25,:)); eval(nut(26,:)); eval(nut(27,:)); eval(nut(28,:));
   elseif (i>=1)&(i<=(m-2))&(j==(n-1))
      eval(nut(1,:)); eval(nut(2,:)); eval(nut(3,:)); eval(nut(4,:));
      eval(nut(5,:)); eval(nut(7,:)); eval(nut(8,:)); eval(nut(9,:));
      eval(nut(10,:)); eval(nut(11,:)); eval(nut(19,:)); eval(nut(20,:));
      eval(nut(21,:)); eval(nut(22,:)); eval(nut(23,:)); eval(nut(24,:));
      eval(nut(25,:)); eval(nut(26,:)); eval(nut(27,:)); eval(nut(28,:));
   elseif (i>=1)&(i<=(m-2))&(j==n)
      eval(nut(8,:)); eval(nut(22,:)); eval(nut(23,:)); eval(nut(24,:));
      eval(nut(25,:)); eval(nut(26,:)); eval(nut(27,:)); eval(nut(28,:));
   elseif (i==(m-1))&(j==-1)
      eval(nut(6,:)); eval(nut(14,:)); eval(nut(15,:)); eval(nut(16,:));
      eval(nut(17,:)); eval(nut(18,:));
   elseif (i==(m-1))&(j==0)
      eval(nut(1,:)); eval(nut(2,:)); eval(nut(3,:)); eval(nut(4,:));
      eval(nut(6,:)); eval(nut(7,:)); eval(nut(14,:)); eval(nut(15,:));
      eval(nut(16,:)); eval(nut(17,:)); eval(nut(18,:)); eval(nut(19,:));
      eval(nut(20,:)); eval(nut(21,:));
   elseif (i==(m-1))&(j>=1)&(j<=(n-2))
      eval(nut(1,:)); eval(nut(2,:)); eval(nut(3,:)); eval(nut(4,:));
      eval(nut(6,:)); eval(nut(7,:)); eval(nut(8,:)); eval(nut(14,:));
      eval(nut(15,:)); eval(nut(16,:)); eval(nut(17,:)); eval(nut(18,:));
      eval(nut(19,:)); eval(nut(20,:)); eval(nut(21,:)); eval(nut(22,:));
      eval(nut(23,:)); eval(nut(24,:)); eval(nut(25,:)); eval(nut(26,:));
   elseif (i==(m-1))&(j==(n-1))
      eval(nut(1,:)); eval(nut(2,:)); eval(nut(3,:)); eval(nut(4,:));
      eval(nut(7,:)); eval(nut(8,:)); eval(nut(19,:)); eval(nut(20,:));
      eval(nut(21,:)); eval(nut(22,:)); eval(nut(23,:)); eval(nut(24,:));
      eval(nut(25,:)); eval(nut(26,:));
   elseif (i==(m-1))&(j==n)
      eval(nut(8,:)); eval(nut(22,:)); eval(nut(23,:)); eval(nut(24,:));
      eval(nut(25,:)); eval(nut(26,:));
   elseif (i==m)&(j==-1)
      eval(nut(17,:)); eval(nut(18,:));
   elseif (i==m)&(j==0)
      eval(nut(7,:)); eval(nut(17,:)); eval(nut(18,:)); eval(nut(19,:)); 
      eval(nut(20,:)); eval(nut(21,:));
   elseif (i==m)&(j>=1)&(j<=(n-2))
      eval(nut(7,:)); eval(nut(17,:)); eval(nut(18,:)); eval(nut(19,:));
      eval(nut(20,:)); eval(nut(21,:)); eval(nut(22,:)); eval(nut(23,:));
   elseif (i==m)&(j==(n-1))
      eval(nut(7,:)); eval(nut(19,:)); eval(nut(20,:)); eval(nut(21,:));
      eval(nut(22,:)); eval(nut(23,:));
   elseif (i==m)&(j==n)
      eval(nut(22,:)); eval(nut(23,:));
   end  
   axis([p(3) p(m+3) q(3) q(n+3)]);
   str=sprintf('Q^*_{%g%g}',i,j);
   title(str);
end