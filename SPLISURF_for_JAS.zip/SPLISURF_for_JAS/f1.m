function f=f1(x,y)
%F1   Test function f1:
%     f1(x,y)=sqrt(x^2+y^2)-0.6)^4   if   sqrt(x^2+y^2)>0.6
%     f1(x,y)=0                      elsewhere
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
% [3] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
f=zeros(size(x));
R=(sqrt(x.^2+y.^2)>0.6);
f=f+R.*(sqrt(x.^2+y.^2)-0.6).^4;