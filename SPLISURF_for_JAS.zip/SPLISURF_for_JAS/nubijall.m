function nubijall(p,q)
%NUBIJALL   It plots the 'non-uniform' B-spline B^*_{IJ} in [A,B]�[C,D],
%           for given vectors P and Q and for all I=-1,...,M, J=-1,...,N;
%           M=LENGTH(P)-5, N=LENGTH(Q)-5; M,N<=6.
%               
%           See also NUBIJPLT.
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
m=length(p)-5;
n=length(q)-5;
for i=-1:m
  for j=-1:n
     nubijplt(p,q,i,j)
     pause(1)
     hold off
  end
end