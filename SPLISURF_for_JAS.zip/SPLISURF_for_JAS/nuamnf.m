%NUAMNF    This is a demo.
%          APPROXIMATION OF SOME TEST FUNCTIONS 
%          BY BIVARIATE QUADRATIC C^1 QUASI-INTERPOLATING SPLINES
%          ON NON UNIFORM TYPE-2 TRIANGULATIONS
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, Some performances of local bivariate
% quadratic C^1 quasi-interpolating splines on nonuniform
% type-2 triangulations, J. Comp. Appl. Math. 173 (2005), 21-37.
%
disp(' ');
disp(' ');
disp('APPROXIMATION OF SOME TEST FUNCTIONS');
disp('BY BIVARIATE QUADRATIC C^1 QUASI-INTERPOLATING SPLINES');
disp('ON NON UNIFORM TYPE-2 TRIANGULATIONS');
disp(' ');
disp(' ');
disp(' ');
disp('In the case of non uniform type-2 triangulations');
disp('we have a more interesting approach in those cases');
disp('where the functions/data that have to be approximated');
disp('present multiple features and abrupt transitions.');
disp('A possibile solution is to ''adapt'' the triangulation');
disp('by thickening the grid points where the functions/data');
disp('have some irregularities and sharp variations.');
disp(' ');
disp('So let''s suppose we want to approximate data taken from the test');
disp('function defined in the M-file f1.m and obtained by the following');
disp('commands on the domain [0,1]x[0,1]:');
disp(' ');
echo on
u=linspace(0,1,30);
v=linspace(0,1,30);
[U,V]=meshgrid(u,v);
Z=f1(U,V);
mesh(U,V,Z)
echo off
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('For this kind of function we can use the non uniform type-2 triangulation');
disp('defined in the M-file sinsinp.m for m=n=8:');
echo on
m=8; n=8; a=0; b=1; c=0; d=1;
[p,q]=sinsinp(m,n,a,b,c,d);
[p' q']
echo off
disp('where p and q are two real vectors defining the grid of the triangulation.');
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('Let''s plot this partition for m=n=32, by using the M-file draw.m:');
disp(' ');
echo on
[p1,q1]=sinsinp(32,32,a,b,c,d);
figure
draw(p1,q1)
echo off
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('First we construct the functionals matrix');
disp('defining the spline operator V^*_{88} in [0,1]x[0,1]:');
disp(' ');
echo on
l=nulv(p,q,0,1,0,1,'f1.m');
echo off
disp(' ');
disp('Then we evaluate the spline at the points uxv of [0,1]x[0,1]:');
disp(' ');
echo on
z=nuamn(u,v,p,q,0,1,0,1,l)';
echo off
disp(' ');
disp('... and we plot the spline approximation by using');
disp(' ');
echo on
figure
mesh(u,v,z)
xlabel('x'); ylabel('y'); zlabel('z');
echo off
disp(' ');
disp('We compute the maximum absolute error at the points uxv by:');
echo on
max_err=max(max(z-Z))
echo off
disp(' ');
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp(' ');
clf
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Now let''s see another example.');
disp(' ');
disp('On the domain [-1,1]x[-1,1] we consider the test function');
disp(' ');
echo on
u=linspace(-1,1,30);
v=linspace(-1,1,30);
[U,V]=meshgrid(u,v);
Z=f2(U,V);
mesh(U,V,Z)
echo off
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('For this kind of function we can use the non uniform type-2 triangulation');
disp('defined in the M-file evenp.m for m=n=8:');
echo on
m=8; n=8; a=-1; b=1; c=-1; d=1;
[p,q]=evenp(m,n,a,b,c,d);
[p' q']
echo off
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('Let''s plot this partition for m=n=32, by using the M-file draw.m:');
disp(' ');
echo on
[p1,q1]=evenp(32,32,a,b,c,d);
figure
draw(p1,q1)
echo off
disp(' ');
disp('... press any key to continue...');
pause
disp(' ');
disp('The functionals matrix defining the spline operator');
disp('V^*_{mn} for m=8, n=8 is the following:');
disp(' ');
echo on
l=nulv(p,q,0,1,0,1,'f2.m');
echo off
disp(' ');
disp('Thus we evaluate the spline at the points uxv of [0,1]x[0,1],');
disp(' ');
echo on
z=nuamn(u,v,p,q,0,1,0,1,l)';
echo off
disp(' ');
disp('... we plot the spline approximation');
disp(' ');
echo on
figure
mesh(u,v,z)
axis([u(1) u(length(u)) v(1) v(length(v)) min(min(z)) max(max(z))])
xlabel('x'); ylabel('y'); zlabel('z');
echo off
disp(' ');
disp('... and we compute the maximum absolute error at the points uxv:');
echo on
max_err=max(max(z-Z))
echo off