function l=lv(m,n,a,b,c,d,sf)
%LV     It returns the matrix L of size (M+2)(N+2) of the linear functionals
%       defining the spline V_{MN}F for a given test function F over an open
%       set containing the rectangle [A,B]x[C,D], where M is the subdivisions
%       number of [A,B] and N is the subdivisions number of [C,D].
%       SF is the string containing either the function F or the name of 
%       the m-file with .M extension in which the function F is defined.
%
%       Ex. sf='(1+2*exp((-3)*(sqrt(x.^2+y.^2)-6.7))).^(-1/2)';
%          	l=lv(3,3,0,10,0,10,sf)
%
%           return
%
%           l=
%               0.0010    0.0010    0.0826    0.9955    1.0000
%               0.0010    0.0010    0.0826    0.9955    1.0000
%               0.0826    0.0826    0.7769    0.9999    1.0000
%               0.9955    0.9955    0.9999    1.0000    1.0000
%               1.0000    1.0000    1.0000    1.0000    1.0000
%
%       See also AMN, LW. 
%
% [1] C. Dagnino, P. Lamberti, On C^1 quasi-interpolating splines
% with type-2 triangulations, Progetto MURST: "Analisi Numerica: Metodi
% e Software Matematico", Monografia n. 4, Ferrara 2000, 1-50.
% [2] C. Dagnino, P. Lamberti, On the approximation power of bivariate
% quadratic C^1 splines, J. Comp. Appl. Math. 131 (2001), 321-332.
%
[h k]=size(sf);
if k~=1
   sf1=sf(k-1:k);
else
   sf1=sf;
end
[XI,YJ]=meshgrid(-1/(2*m):1/m:(2*m+1)/(2*m),-1/(2*n):1/n:(2*n+1)/(2*n));
if strcmp(sf1,'.m')
   sf2=sf(1:k-2);
   l=feval(sf2,(b-a)*XI'+a,(d-c)*YJ'+c);
else
   x=(b-a)*XI'+a;
   y=(d-c)*YJ'+c;
   l=eval(sf);
end